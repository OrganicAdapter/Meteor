﻿# MSSCVLib



This project contains common interfaces and model classes for the MSSCV projects.