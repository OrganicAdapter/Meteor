﻿# Bsmrq.Imaging.AForgeExtensions



This project contains filters and extension methods extending the well-known AForge library.