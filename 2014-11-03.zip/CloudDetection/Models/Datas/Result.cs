﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudDetection.Models.Datas
{
    public class Result
    {
        public string Type { get; set; }
        public int Cloudiness { get; set; }
    }
}
